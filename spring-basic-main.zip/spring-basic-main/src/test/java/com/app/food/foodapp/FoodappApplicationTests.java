package com.app.food.foodapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodappApplicationTests {

    @Test
    void contextLoads() {
    }

}
